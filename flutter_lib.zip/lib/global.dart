library globals;

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart' show User;
import 'package:flutter/cupertino.dart' show BuildContext, PageController;
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart' show SharedPreferences;
import 'package:ngp/database.dart';
import 'dart:io';
import 'package:ngp/ui/alert.dart';


SharedPreferences? prefs;
ThemeMode darkMode = ThemeMode.system;

db? Database;
Map<String,CollectionReference> collectionMap = {}; 
User? account;
account_obj? accObj;
String? loggedUID;
String? passcode;
int accountType = -1;
int eventsCount = 0;
int notificationCount = 0;
int assignmentCount = 0;
int test = 0;
bool networkAvailable = false;
bool isLoggedIn = false;
bool loaded = false;
bool loginScreenRoute = false;
bool choiceRoute = false;
bool loginRoute = false;
bool bgImage = false;
void Function()? loginRouteCloseFn;
void Function()? rootRefresh;
void Function()? bgRefresh;
Alert alert = Alert();
BuildContext? loginRouteCTX;
BuildContext? loginScreenRouteCTX;
BuildContext? choiceRouteCTX;
BuildContext? rootCTX;
PageController? pageControl;
dynamic temp;

void updateSettingsFromStorage() async {
  SharedPreferences pref = await SharedPreferences.getInstance();
  prefs = pref;
  darkMode = prefs!.getBool("dark mode") != null ?( prefs!.getBool("dark mode") == true ? ThemeMode.dark : ThemeMode.light): ThemeMode.light;
  bgImage = prefs!.getBool("bg image") != null ? prefs!.getBool("bg image")! : false;
  passcode = prefs!.getString("passcode");
  rootRefresh!();
}

Future<bool> checkNetwork() async {
  try {
    final result = await InternetAddress.lookup('example.com');
    if (result.isNotEmpty && result[0].rawAddress.isNotEmpty) {
      networkAvailable = true;
    }
  } on SocketException catch (_) {
    networkAvailable = false;
  }
  return networkAvailable;
}

void initGlobalVar() async {
  accObj = account_obj();
}

Widget textWidget(String text) {
  return Text(text, style: TextStyle(
    color: Theme.of(rootCTX!).textSelectionTheme.selectionColor,
  ),);
}

Widget textWidgetWithBool(String text, bool enable) {
  return Text(text, style: TextStyle(
    color: (enable==true) ? Theme.of(rootCTX!).textSelectionTheme.cursorColor : Theme.of(rootCTX!).textSelectionTheme.selectionColor
  ),);
}
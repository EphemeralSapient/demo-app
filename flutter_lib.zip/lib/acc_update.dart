
import 'package:flutter/foundation.dart';

import './global.dart' as global;


bool isLock = false;
void initUpdater() {
  if (isLock == true || global.accountType == 3) return; else isLock=true;

  // Upate occurred on user database
  global.Database!.addCollection("acc", "/acc").doc(global.loggedUID!).snapshots().listen((event) {
      
      final oldData = global.accObj;
      final newData = global.accObj!.fromJSON(event.data() as Map<String, Object?>);

      
    },
    onError: (e) {
      debugPrint("What, error? $e");
    }
  );
}
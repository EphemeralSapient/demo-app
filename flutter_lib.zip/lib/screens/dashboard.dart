import 'package:flutter/material.dart';
import 'package:ngp/sub_screen/assignments.dart';
import 'package:transparent_image/transparent_image.dart';
import '../sub_screen/notification_centre.dart';
import '../sub_screen/events.dart';
import 'package:marquee/marquee.dart' show Marquee;
import 'package:firebase_auth/firebase_auth.dart' show FirebaseAuth;
import 'package:ngp/global.dart' as global;

class dash extends StatelessWidget {
  @override
  Widget build(context) {
    debugPrint("building dash screen");
    return Scaffold(
      backgroundColor: Theme.of(context).buttonColor,
      body: SingleChildScrollView(
        child: Column(children: [
          SizedBox(
            height: 200,
            child: Padding(
                padding: const EdgeInsets.all(20),
                child: Stack(
                  children: [
      
                    Container(
                      padding: const EdgeInsets.all(3),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(50),
                        color: Colors.transparent,
                        border: Border.all(
                          width: 1.1,
                          color: Colors.red,
                        ),
                      ),
                      width: 50,
                      height: 50,
                      child: ClipOval(
                        child: global.account?.isAnonymous != true
                            ? FadeInImage.assetNetwork(placeholder: "asset/images/loading.gif", image: global.account!.photoURL!)
                            : const Icon(Icons.person),
                      ),
                    ),
                    Positioned(
                        top: 20,
                        left: 60,
                        child: RichText(
                            text: TextSpan(children: [
                          TextSpan(
                              text: "Hello there, ",
                              style: TextStyle(
                                  color: Theme.of(context)
                                      .textSelectionTheme
                                      .selectionHandleColor,
                                  fontFamily: "Montserrat")),
                          TextSpan(
                              text: global.account!.isAnonymous == true
                                  ? "Guest"
                                  : "${global.account!.displayName}!",
                              style: TextStyle(
                                  color: Theme.of(context)
                                      .textSelectionTheme
                                      .cursorColor,
                                  fontFamily: "Montserrat"))
                        ]))),
                    Padding(
                        padding: EdgeInsets.only(top: 60, left: 75),
                        child: ElevatedButton(
                            style: ElevatedButton.styleFrom(
                                primary: Theme.of(context).buttonColor,
                                shadowColor: Colors.transparent,
                                shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(10))),
                            onPressed: (() {
                              debugPrint("ok");
                            }),
                            child: Padding(
                              padding: const EdgeInsets.only(bottom: 10, top: 5),
                              child: SizedBox.expand(
                                child: Stack(
                                  children: [
                                    Text("Current on-going class : ",
                                        style: TextStyle(
                                            color: Theme.of(context)
                                                .textSelectionTheme
                                                .selectionHandleColor)),
                                    Padding(
                                        padding: const EdgeInsets.only(top: 25),
                                        child: Marquee(
                                            text: 'CS3251 - Programming in C',
                                            //  textDirection: TextDirection.rtl,
                                            blankSpace: 20,
                                            style: TextStyle(
                                                color: Theme.of(context)
                                                    .textSelectionTheme
                                                    .selectionColor,
                                                fontSize: 25,
                                                fontWeight: FontWeight.bold,
                                                fontFamily: "Raleway"),
                                            pauseAfterRound: Duration(seconds: 2),
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start)),
                                    Align(
                                        alignment: Alignment.bottomLeft,
                                        child: Text("9:10 AM",
                                            style: TextStyle(
                                                color: Theme.of(context)
                                                    .textSelectionTheme
                                                    .selectionHandleColor))),
                                    Align(
                                        alignment: Alignment.bottomRight,
                                        child: Text("9:55 AM",
                                            style: TextStyle(
                                                color: Theme.of(context)
                                                    .textSelectionTheme
                                                    .selectionHandleColor)))
                                  ],
                                ),
                              ),
                            ))),
                  
                    
                    
             
                  
                  
                  ],
                )),
          ),
          
          Padding(
            padding: EdgeInsets.all(20),
            child: Column(
              children: [
                notifyUi(),

                const SizedBox(height: 25,),

                eventsUi(),

                const SizedBox(height: 25,),

                assignmentUi(),

              ],
            ),
          ),
        
          const SizedBox(height: 100)
        ]),
      ),
    );
  }
}

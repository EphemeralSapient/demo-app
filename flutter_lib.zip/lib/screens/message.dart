
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';

class messages extends StatelessWidget {

  @override 
  Widget build(context) {
    return Scaffold(
      backgroundColor: Theme.of(context).buttonColor,
      body: Center(child: Text("[ WIP ]")),
    );
  }
}